

function post_params = gpr_init(T, D, theta_m)

post_params = zeros(0, 2);
